#ifndef _RNG_H_
#define _RNG_H_

int kmeans_rand();
void kmeans_srand(unsigned int seed);

#endif
